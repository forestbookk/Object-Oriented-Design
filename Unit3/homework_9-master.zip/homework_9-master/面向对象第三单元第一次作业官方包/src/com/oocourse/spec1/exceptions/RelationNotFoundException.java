package com.oocourse.spec1.exceptions;

public abstract class RelationNotFoundException extends Exception {

    public abstract void print();
}
