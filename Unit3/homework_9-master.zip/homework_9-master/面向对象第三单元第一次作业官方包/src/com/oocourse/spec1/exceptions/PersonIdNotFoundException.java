package com.oocourse.spec1.exceptions;

public abstract class PersonIdNotFoundException extends Exception {

    public abstract void print();
}
