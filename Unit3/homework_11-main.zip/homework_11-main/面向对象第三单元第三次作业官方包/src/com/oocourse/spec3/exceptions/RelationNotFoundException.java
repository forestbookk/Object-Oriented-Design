package com.oocourse.spec3.exceptions;

public abstract class RelationNotFoundException extends Exception {

    public abstract void print();
}
