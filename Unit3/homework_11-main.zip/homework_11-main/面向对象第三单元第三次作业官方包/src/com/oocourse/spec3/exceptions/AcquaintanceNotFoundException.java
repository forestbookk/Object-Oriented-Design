package com.oocourse.spec3.exceptions;

public abstract class AcquaintanceNotFoundException extends Exception {

    public abstract void print();
}
