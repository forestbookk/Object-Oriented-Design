public enum Process
{
    A, B, C, D, COMPLETE;
}
